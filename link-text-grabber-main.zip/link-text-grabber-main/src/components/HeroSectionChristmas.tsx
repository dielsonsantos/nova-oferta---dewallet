import { MarqueeBanner } from "./MarqueeBanner";
import natalImage from "@/assets/natal-produtos.webp";
export const HeroSectionChristmas = () => {
  return <section className="bg-black relative overflow-hidden">
      
      <div className="py-4 px-4 pt-16 relative z-30">
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-xl md:text-3xl font-black mb-2 text-white uppercase tracking-tight leading-tight" style={{
          textShadow: '0 4px 12px rgba(0,0,0,0.8), 0 2px 4px rgba(0,0,0,0.6), 0 0 20px rgba(0,0,0,0.4)'
        }}>
          🎄 NATAL WELONG HAIR 🎄
        </h1>
        
        <h2 className="text-xl md:text-2xl font-bold mb-6 text-christmas-gold" style={{
          textShadow: '0 3px 10px rgba(0,0,0,0.9), 0 2px 4px rgba(0,0,0,0.7), 0 0 15px rgba(0,0,0,0.5)'
        }}>
          ⭐ O melhor presente de Natal para você!⭐
        </h2>
        
        <div className="mb-6">
          <img src={natalImage} alt="Welong Hair - Produtos Completos de Natal" className="w-full h-auto rounded-lg shadow-2xl" />
        </div>

        
        <p className="text-lg md:text-xl font-bold text-white mb-2" style={{
          textShadow: '0 3px 10px rgba(0,0,0,0.9), 0 2px 4px rgba(0,0,0,0.7), 0 0 15px rgba(0,0,0,0.5)'
        }}>
          Transforme seu cabelo neste Natal com o tratamento que está mudando a vida de milhares de mulheres!
        </p>
      </div>
      </div>

      <MarqueeBanner />
    </section>;
};