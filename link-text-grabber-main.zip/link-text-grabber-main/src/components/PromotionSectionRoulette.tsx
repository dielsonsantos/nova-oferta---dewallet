import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RouletteDialog } from "@/components/RouletteDialog";
import { format } from "date-fns";

export const PromotionSectionRoulette = () => {
  const [showRoulette, setShowRoulette] = useState(false);
  const today = format(new Date(), "dd/MM/yy");

  return (
    <>
      <RouletteDialog open={showRoulette} onOpenChange={setShowRoulette} />
    <section className="py-6 px-4 bg-white relative overflow-hidden">
      <div className="max-w-2xl mx-auto text-center relative z-10">
        <h2 className="text-xl md:text-2xl font-bold mb-6 uppercase flex items-center justify-center gap-2">
          <span className="text-2xl">🎁</span>
          PROMOÇÃO EXCLUSIVA
        </h2>

        <p className="text-base mb-4">
          Comprando ainda hoje, você recebe 3 brindes especiais totalmente grátis:
        </p>

        <ul className="space-y-2 mb-6 text-left">
          <li className="flex items-start gap-2 text-base">
            <span className="text-lg flex-shrink-0">✅</span>
            <span>Escova de cabelo personalizada</span>
          </li>
          <li className="flex items-start gap-2 text-base">
            <span className="text-lg flex-shrink-0">✅</span>
            <span>Touca anti-frizz profissional</span>
          </li>
          <li className="flex items-start gap-2 text-base">
            <span className="text-lg flex-shrink-0">✅</span>
            <span>Necessaire exclusiva Welong</span>
          </li>
        </ul>

        <div className="flex items-end bg-yellow-50 border border-yellow-300 text-yellow-800 pl-2 pr-[0px] py-[0px] rounded-none mb-6 text-left leading-none gap-0">
          <span className="text-base flex-shrink-0 mr-1">⚠️</span>
          <p className="text-sm w-full pr-[0px] pl-[0px] m-[0px] pb-[0px] leading-none tracking-tight">
            Somente Hoje ({today}) brindes disponíveis enquanto durarem os estoques.
          </p>
        </div>

        <Button 
          size="lg"
          onClick={() => setShowRoulette(true)}
          variant="christmas"
          className="w-full max-w-sm font-bold py-4 rounded-full text-base mb-6"
        >
          🎄 GIRAR ROLETA E COMPRAR AGORA 🎁
        </Button>
      </div>
    </section>
    </>
  );
};
