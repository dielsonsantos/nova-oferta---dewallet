import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RouletteDialog } from "@/components/RouletteDialog";
export const HowItWorksRoulette = () => {
  const [showRoulette, setShowRoulette] = useState(false);
  return <>
      <RouletteDialog open={showRoulette} onOpenChange={setShowRoulette} />
    <section className="py-6 px-4 bg-white relative overflow-hidden">
      <div className="max-w-2xl mx-auto text-center relative z-10">
        <h2 className="text-xl md:text-2xl font-bold mb-4 uppercase text-center">
          Como o Welong Hair funciona?
        </h2>
        
        <p className="text-base mb-4 text-center">
          Cabelos fracos, ralos e cheios de falhas têm um motivo: falta de estímulo no folículo capilar. O Welong age diretamente onde o problema começa, estimulando o crescimento de novos fios com mais força e espessura. Ele também pode ser usado na barba — homens têm obtido resultados incríveis com o crescimento facial também.
        </p>
        
        <p className="text-base mb-6 text-center">
          Aplicação simples, segura e sem nenhuma reação adversa.
        </p>

        <Button size="lg" onClick={() => setShowRoulette(true)} variant="christmas" className="w-full max-w-sm font-bold py-4 rounded-full text-base">
          🎄 GIRAR ROLETA E COMPRAR AGORA 🎁
        </Button>
      </div>
    </section>
    </>;
};