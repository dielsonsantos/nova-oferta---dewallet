export const MarqueeBanner = () => {
  return (
    <div className="bg-christmas-red py-2 overflow-hidden w-full relative">
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .marquee-content {
          animation: marquee 60s linear infinite;
          display: flex;
          width: fit-content;
        }
      `}</style>
      <div className="marquee-content">
        <div className="flex whitespace-nowrap shrink-0">
          {Array(8).fill(null).map((_, i) => (
            <span key={i} className="inline-block text-white font-bold text-base px-8 uppercase">
              🎁 Gire a roleta e ganhe seu presente de Natal! 🎄
            </span>
          ))}
        </div>
        <div className="flex whitespace-nowrap shrink-0">
          {Array(8).fill(null).map((_, i) => (
            <span key={i} className="inline-block text-white font-bold text-base px-8 uppercase">
              🎁 Gire a roleta e ganhe seu presente de Natal! 🎄
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
